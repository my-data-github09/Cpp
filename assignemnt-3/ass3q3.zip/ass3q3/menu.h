#ifndef menu_h
#define menu_h

enum Emenu
{
    EXIT,
    GET_RADIUS,
    GET_HEIGHT,
    CHANGE_RADIUS,
    CHANGE_HEIGHT,
    CALCULATE_VOLUME
};


Emenu menu();

#endif